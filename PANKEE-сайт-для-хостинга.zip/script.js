/* =========================================================
   PANKEE · скрипты сайта
   ========================================================= */
(() => {
  'use strict';

  /* ---------- Данные: тарифная сетка (из КП) ---------- */
  const TIERS = [
    { max: 10,       label: 'до 10 шт' },
    { max: 40,       label: '10–40 шт' },
    { max: 70,       label: '40–70 шт' },
    { max: 100,      label: '70–100 шт' },
    { max: 150,      label: '100–150 шт' },
    { max: 200,      label: '150–200 шт' },
    { max: 250,      label: '200–250 шт' },
    { max: 300,      label: '250–300 шт' }
  ];

  const VARIANTS = {
    1: {
      name: 'Готовые решения',
      note: 'размеры бренда, цвета и ткани из наличия',
      suit:  [6500, 6000, 5500, 5000, 5000, 4500, 4200, 4100],
      emb:   [600, 550, 500, 450, 400, 350, 300, 300]
    },
    2: {
      name: 'Подбор под клинику',
      note: 'модели бренда, подбор цвета и ткани',
      suit:  [7000, 6500, 6000, 5800, 5500, 5300, 5100, 4800],
      emb:   [650, 600, 550, 500, 450, 400, 350, 300]
    },
    3: {
      name: 'Пошив по параметрам',
      note: 'индивидуальные мерки, конструктор моделей',
      suit:  [7500, 7000, 6500, 6200, 5800, 5500, 5200, 5000],
      emb:   [650, 600, 550, 500, 450, 400, 350, 300]
    },
    4: {
      name: 'Полный кастом',
      note: 'по референсам, создание или изменение лекал',
      suit:  [10000, 9500, 9000, 8500, 8000, 7800, 7300, 7100],
      emb:   [650, 600, 550, 500, 450, 400, 350, 300]
    }
  };

  const LOOKS = [
    { slug: 'olivia',   name: 'Оливия',   sex: 'women', color: '#523A3C' },
    { slug: 'vivien',   name: 'Вивьен',   sex: 'women', color: '#161519' },
    { slug: 'celine',   name: 'Селин',    sex: 'women', color: '#0D1F3D' },
    { slug: 'lavi',     name: 'Лави',     sex: 'women', color: '#A9B8AE' },
    { slug: 'shade',    name: 'Шадэ',     sex: 'women', color: '#313648' },
    { slug: 'ari',      name: 'Ари',      sex: 'women', color: '#75857A' },
    { slug: 'michelle', name: 'Мишель',   sex: 'women', color: '#9FB4D2' },
    { slug: 'rafaelo',  name: 'Рафаэло',  sex: 'women', color: '#D288A5' },
    { slug: 'snow',     name: 'Сноу',     sex: 'men',   color: '#22264F' },
    { slug: 'chic',     name: 'Чик',      sex: 'men',   color: '#74B8AB' },
    { slug: 'valli',    name: 'Валли',    sex: 'men',   color: '#C05A3D' },
    { slug: 'tor',      name: 'Тор',      sex: 'men',   color: '#77775F' },
    { slug: 'kai',      name: 'Кай',      sex: 'men',   color: '#A6A5C4' },
    { slug: 'kasma',    name: 'Касма',    sex: 'men',   color: '#1E223C' }
  ];

  const fmt = n => new Intl.NumberFormat('ru-RU').format(n).replace(/\u00A0/g, ' ');

  /* ---------- Тема: восстановление + переключение ---------- */
  const THEMES = {
    atelier: ['#F4F1EA', '#1C2340', '#CE3A2B', '#DED6C6'],
    clinic:  ['#F1F4F3', '#1F2A2E', '#0E5C4C', '#D3DFDB'],
    terra:   ['#F2E9DC', '#2B211C', '#B4553A', '#DFCDB8'],
    night:   ['#12141A', '#F0EDE6', '#E4634F', '#2E3441']
  };
  const THEME_LABELS = ['фон', 'текст', 'акцент', 'линия'];

  const applyTheme = (name, persist = true) => {
    document.documentElement.dataset.theme = name;
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) metaTheme.setAttribute('content', THEMES[name][0]);
    document.querySelectorAll('[data-set-theme]').forEach(b => {
      const on = b.dataset.setTheme === name;
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-checked', String(on));
    });
    const list = document.getElementById('ppTokens');
    if (list) {
      list.innerHTML = THEMES[name].map((c, i) =>
        `<li><i style="background:${c}"></i><span>${THEME_LABELS[i]}</span><b>${c.toUpperCase()}</b></li>`
      ).join('');
    }
    if (persist) { try { localStorage.setItem('pankee-theme', name); } catch (e) {} }
  };

  let stored = 'atelier';
  try { stored = localStorage.getItem('pankee-theme') || 'atelier'; } catch (e) {}
  if (THEMES[stored]) applyTheme(stored, false);

  const palettePanel = document.getElementById('palettePanel');
  const paletteTrigger = document.getElementById('paletteTrigger');
  const paletteFab = document.getElementById('paletteFab');
  const setPanel = open => {
    palettePanel.classList.toggle('is-open', open);
    palettePanel.setAttribute('aria-hidden', String(!open));
    paletteTrigger?.setAttribute('aria-expanded', String(open));
    paletteFab?.setAttribute('aria-expanded', String(open));
  };
  paletteTrigger?.addEventListener('click', () => setPanel(!palettePanel.classList.contains('is-open')));
  paletteFab?.addEventListener('click', () => setPanel(!palettePanel.classList.contains('is-open')));
  document.getElementById('paletteClose')?.addEventListener('click', () => setPanel(false));
  document.querySelectorAll('[data-set-theme]').forEach(btn =>
    btn.addEventListener('click', () => applyTheme(btn.dataset.setTheme))
  );
  document.addEventListener('keydown', e => { if (e.key === 'Escape') setPanel(false); });

  /* ---------- Хедер ---------- */
  const header = document.getElementById('header');
  const progressBar = document.getElementById('progressBar');
  const onScroll = () => {
    const y = window.scrollY;
    header.classList.toggle('is-stuck', y > 12);
    const h = document.documentElement.scrollHeight - window.innerHeight;
    if (progressBar) progressBar.style.width = (h > 0 ? (y / h) * 100 : 0) + '%';
    document.querySelectorAll('[data-parallax]').forEach(el => {
      const speed = parseFloat(el.dataset.parallax) || 0;
      el.style.setProperty('--pl', (y * speed).toFixed(1) + 'px');
    });
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- Мобильное меню ---------- */
  const burger = document.getElementById('burger');
  const nav = document.getElementById('nav');
  burger?.addEventListener('click', () => {
    const open = nav.classList.toggle('is-open');
    burger.setAttribute('aria-expanded', String(open));
    document.body.classList.toggle('is-locked', open);
  });
  nav?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    nav.classList.remove('is-open');
    burger.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('is-locked');
  }));

  /* ---------- Reveal при скролле ---------- */
  const revealEls = document.querySelectorAll('[data-reveal]');
  const io = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const delay = parseInt(entry.target.dataset.delay || '0', 10);
      setTimeout(() => entry.target.classList.add('is-in'), delay);
      io.unobserve(entry.target);
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
  revealEls.forEach(el => io.observe(el));
  document.querySelectorAll('.stitch-divider').forEach(el => io.observe(el));

  /* ---------- Счётчики в hero ---------- */
  const counters = document.querySelectorAll('.num[data-count]');
  const cIO = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const end = parseInt(el.dataset.count, 10);
      const suffix = el.dataset.suffix || '';
      if (suffix) { el.textContent = end + suffix; cIO.unobserve(el); return; }
      const dur = 1100;
      const t0 = performance.now();
      const tick = t => {
        const p = Math.min(1, (t - t0) / dur);
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(end * eased);
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      cIO.unobserve(el);
    });
  }, { threshold: 0.6 });
  counters.forEach(el => cIO.observe(el));

  /* ---------- Before / After ---------- */
  const range = document.getElementById('compareRange');
  const clip = document.getElementById('compareClip');
  const handle = document.getElementById('compareHandle');
  if (range && clip) {
    const paint = v => {
      clip.style.width = v + '%';
      if (handle) handle.style.left = v + '%';
      const top = clip.querySelector('.compare-img');
      if (top) top.style.width = (clip.parentElement.clientWidth) + 'px';
    };
    range.addEventListener('input', e => paint(e.target.value));
    window.addEventListener('resize', () => paint(range.value));
    // drag anywhere on the frame
    const frame = clip.parentElement;
    let dragging = false;
    const setFromEvent = clientX => {
      const r = frame.getBoundingClientRect();
      const v = Math.max(0, Math.min(100, ((clientX - r.left) / r.width) * 100));
      range.value = v; paint(v);
    };
    frame.addEventListener('pointerdown', e => { dragging = true; setFromEvent(e.clientX); });
    window.addEventListener('pointermove', e => { if (dragging) setFromEvent(e.clientX); });
    window.addEventListener('pointerup', () => { dragging = false; });
    paint(range.value);
  }

  /* ---------- Калькулятор ---------- */
  const qtyRange = document.getElementById('qtyRange');
  const qtyOut = document.getElementById('qtyOut');
  const resSuit = document.getElementById('resSuit');
  const resEmb = document.getElementById('resEmb');
  const resTotal = document.getElementById('resTotal');
  const resNote = document.getElementById('resNote');
  const calcNext = document.getElementById('calcNext');
  const calcVariantName = document.getElementById('calcVariantName');
  const priceTable = document.getElementById('priceTable');
  const tableCaption = document.getElementById('tableCaption');

  let currentVariant = 1;

  const tierIndex = qty => {
    for (let i = 0; i < TIERS.length; i++) if (qty <= TIERS[i].max) return i;
    return TIERS.length - 1;
  };

  const renderCalculator = () => {
    const qty = parseInt(qtyRange.value, 10);
    const v = VARIANTS[currentVariant];
    const i = tierIndex(qty);
    const suit = v.suit[i];
    const emb = v.emb[i];
    qtyOut.textContent = fmt(qty) + ' шт';
    resSuit.textContent = fmt(suit) + ' ₽';
    resEmb.textContent = 'от ' + fmt(emb) + ' ₽';
    resTotal.textContent = fmt((suit + emb) * qty) + ' ₽';
    resNote.textContent = `${fmt(qty)} шт × (${fmt(suit)} + ${fmt(emb)}) ₽`;
    qtyRange.style.setProperty('--fill', ((qty - 6) / (300 - 6)) * 100 + '%');
    calcVariantName.textContent = v.name;

    // сколько добавить до следующей ступени
    const tier = TIERS[i];
    if (i < TIERS.length - 1) {
      const need = tier.max + 1 - qty;
      const nextSuit = v.suit[i + 1];
      const save = (suit - nextSuit) * (tier.max + 1);
      calcNext.innerHTML = need > 0
        ? `+<b>${fmt(need)} шт</b> — и костюм станет <b>${fmt(nextSuit)} ₽</b>. Экономия на партии ≈ <b>${fmt(save)} ₽</b>.`
        : `Ступень <b>${tier.label}</b>: костюм <b>${fmt(suit)} ₽</b>.`;
    } else {
      calcNext.innerHTML = `Максимальный объём: костюм <b>${fmt(suit)} ₽</b> — лучшая цена в сетке.`;
    }

    document.querySelectorAll('.calc-tab').forEach(t => {
      const on = t.dataset.calcVariant === String(currentVariant);
      t.classList.toggle('is-active', on);
      t.setAttribute('aria-selected', String(on));
    });

    renderTable();
  };

  const renderTable = () => {
    if (!priceTable) return;
    const v = VARIANTS[currentVariant];
    const qty = parseInt(qtyRange.value, 10);
    const activeIdx = tierIndex(qty);
    priceTable.querySelector('tbody').innerHTML = TIERS.map((t, i) =>
      `<tr class="${i === activeIdx ? 'is-current' : ''}">
        <td>${t.label}</td>
        <td>${fmt(v.suit[i])}</td>
        <td>от ${fmt(v.emb[i])}</td>
        <td>от ${fmt(v.suit[i] + v.emb[i])}</td>
      </tr>`
    ).join('');
    const slug = { 1: 'В1', 2: 'В2', 3: 'В3', 4: 'В4' }[currentVariant];
    tableCaption.textContent = `Вариант ${currentVariant} (${slug}) — ${v.name}: ${v.note}.`;
    document.querySelectorAll('[data-table]').forEach(b => {
      const on = b.dataset.table === String(currentVariant);
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-selected', String(on));
    });
  };

  qtyRange?.addEventListener('input', renderCalculator);
  document.querySelectorAll('.calc-tab').forEach(tab => tab.addEventListener('click', () => {
    currentVariant = parseInt(tab.dataset.calcVariant, 10);
    renderCalculator();
  }));
  document.querySelectorAll('[data-table]').forEach(btn => btn.addEventListener('click', () => {
    currentVariant = parseInt(btn.dataset.table, 10);
    renderCalculator();
    priceTable?.closest('.tables')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }));
  document.querySelectorAll('[data-qty]').forEach(btn => btn.addEventListener('click', () => {
    qtyRange.value = btn.dataset.qty;
    renderCalculator();
  }));
  document.querySelectorAll('[data-variant-jump]').forEach(a => a.addEventListener('click', () => {
    currentVariant = parseInt(a.dataset.variantJump, 10);
    renderCalculator();
  }));
  if (qtyRange) renderCalculator();

  /* ---------- Коллекции ---------- */
  const looksWrap = document.getElementById('looks');
  if (looksWrap) {
    const ctaCard = `
      <article class="look-cta">
        <span class="look-cta-num">+</span>
        <div class="look-cta-body">
          <h3>Нужен свой цвет или модель?</h3>
          <p>Соберём комплект под ваш фирменный стиль: подбор ткани, цвета и вышивки — и пришлём образцы.</p>
        </div>
        <a class="btn btn-solid" href="#contact">Обсудить <span aria-hidden="true">↗</span></a>
      </article>`;
    looksWrap.innerHTML = LOOKS.map((l, idx) => `
      <article class="look" data-sex="${l.sex}" style="--c:${l.color}">
        <img src="assets/img/look-${l.slug}.webp" width="520" height="650"
             alt="Медицинский костюм PANKEE, коллекция ${l.name}" loading="${idx < 4 ? 'eager' : 'lazy'}" decoding="async">
        <div class="look-info">
          <span class="look-type">${l.sex === 'women' ? 'женская' : 'мужская'}</span>
          <span class="look-name">${l.name}</span>
          <span class="look-dot" aria-hidden="true"></span>
        </div>
        <div class="look-parts" aria-hidden="true">
          <div class="look-part top"><img src="assets/png/${l.slug}-top.png" alt="" loading="lazy" decoding="async"><span>рубашка</span></div>
          <div class="look-part pant"><img src="assets/png/${l.slug}-pant.png" alt="" loading="lazy" decoding="async"><span>брюки</span></div>
        </div>
      </article>
    `).join('') + ctaCard;
  }

  document.querySelectorAll('[data-filter]').forEach(btn => btn.addEventListener('click', () => {
    const f = btn.dataset.filter;
    document.querySelectorAll('[data-filter]').forEach(b => b.classList.toggle('is-active', b === btn));
    document.querySelectorAll('.look').forEach(card => {
      card.classList.toggle('is-hidden', f !== 'all' && card.dataset.sex !== f);
    });
  }));

  /* ---------- Конструктор комплекта ---------- */
  const stageTop = document.getElementById('stageTop');
  const stagePant = document.getElementById('stagePant');
  const stageTopName = document.getElementById('stageTopName');
  const stagePantName = document.getElementById('stagePantName');
  const pickerTop = document.getElementById('pickerTop');
  const pickerPant = document.getElementById('pickerPant');
  const builderCta = document.getElementById('builderCta');
  const fVariantSel = document.getElementById('fVariant');
  const fComment = document.getElementById('fComment');

  const state = { top: 'celine', pant: 'celine' };

  const swapImg = (holder, src, alt) => {
    const img = holder.querySelector('img');
    holder.classList.remove('is-swapping');
    void holder.offsetWidth;
    img.src = src; img.alt = alt;
    holder.classList.add('is-swapping');
  };

  const nameOf = slug => LOOKS.find(l => l.slug === slug)?.name || '';

  const renderBuilder = () => {
    swapImg(stageTop, `assets/png/${state.top}-top.png`, `Рубашка ${nameOf(state.top)}`);
    swapImg(stagePant, `assets/png/${state.pant}-pant.png`, `Брюки ${nameOf(state.pant)}`);
    stageTopName.textContent = `${nameOf(state.top)} · рубашка`;
    stagePantName.textContent = `${nameOf(state.pant)} · брюки`;
    document.querySelectorAll('.pick').forEach(p => {
      const on = (p.dataset.kind === 'top' && p.dataset.slug === state.top) ||
                 (p.dataset.kind === 'pant' && p.dataset.slug === state.pant);
      p.classList.toggle('is-active', on);
      p.setAttribute('aria-checked', String(on));
    });
    if (builderCta) builderCta.textContent = `Обсудить ${nameOf(state.top)} + ${nameOf(state.pant)} →`;
  };

  const fillPicker = (el, kind) => {
    if (!el) return;
    el.innerHTML = LOOKS.map(l => `
      <button class="pick" role="radio" aria-checked="false" data-kind="${kind}" data-slug="${l.slug}" aria-label="${kind === 'top' ? 'Рубашка' : 'Брюки'} ${l.name}" title="${l.name} — ${kind === 'top' ? 'рубашка' : 'брюки'}">
        <img src="assets/png/${l.slug}-${kind}.png" alt="" loading="lazy" decoding="async">
      </button>
    `).join('');
    el.addEventListener('click', e => {
      const btn = e.target.closest('.pick');
      if (!btn) return;
      state[kind] = btn.dataset.slug;
      renderBuilder();
    });
  };
  fillPicker(pickerTop, 'top');
  fillPicker(pickerPant, 'pant');
  if (stageTop) renderBuilder();

  builderCta?.addEventListener('click', () => {
    if (fComment) fComment.value = `Интересует комплект: ${nameOf(state.top)} (рубашка) + ${nameOf(state.pant)} (брюки).`;
  });

  /* ---------- Таймлайн ---------- */
  const tlFill = document.getElementById('tlFill');
  if (tlFill) {
    const tIO = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) { tlFill.style.width = '100%'; tIO.unobserve(e.target); }
      });
    }, { threshold: 0.4 });
    tIO.observe(tlFill.closest('.timeline'));
  }

  /* ---------- Магнитные кнопки ---------- */
  const fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  const noMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (fine && !noMotion) {
    document.querySelectorAll('.magnetic').forEach(btn => {
      btn.addEventListener('pointermove', e => {
        const r = btn.getBoundingClientRect();
        const dx = (e.clientX - r.left - r.width / 2) * 0.12;
        const dy = (e.clientY - r.top - r.height / 2) * 0.18;
        btn.style.transform = `translate(${dx}px, ${dy - 2}px)`;
      });
      btn.addEventListener('pointerleave', () => { btn.style.transform = ''; });
    });
  }

  /* ---------- Форма ---------- */
  const form = document.getElementById('leadForm');
  form?.addEventListener('submit', e => {
    e.preventDefault();
    const data = new FormData(form);
    const body = [
      `Имя: ${data.get('name') || '—'}`,
      `Клиника: ${data.get('clinic') || '—'}`,
      `Контакт: ${data.get('contact') || '—'}`,
      `Объём: ${data.get('qty') || '—'}`,
      `Вариант: ${data.get('variant') || '—'}`,
      `Комментарий: ${data.get('comment') || '—'}`
    ].join('\n');
    const subject = encodeURIComponent('Заявка с сайта PANKEE — расчёт заказа');
    const mailto = `mailto:manager@pankee-store.ru?subject=${subject}&body=${encodeURIComponent(body)}`;
    window.location.href = mailto;
    const ok = document.getElementById('formSuccess');
    if (ok) ok.hidden = false;
  });

  /* ---------- Год ---------- */
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---------- Плавное появление при смене темы: обновляем тени фото ---------- */
  window.addEventListener('load', () => document.body.classList.add('is-ready'));
})();
